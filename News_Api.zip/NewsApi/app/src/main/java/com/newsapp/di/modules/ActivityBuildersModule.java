package com.newsapp.di.modules;

import com.newsapp.NewsMainActivity;
import com.newsapp.core.Category.CategoryFragment;
import com.newsapp.core.Favourite.FavouriteFragment;
import com.newsapp.core.Headline.HeadlineFragment;
import com.newsapp.core.Headline.NewsDetailActivity;
import com.newsapp.core.Search.SearchFragment;
import com.newsapp.core.Setttings.SettingsActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class ActivityBuildersModule {

    @ContributesAndroidInjector
    abstract NewsMainActivity contributesNewsMainActivity();

    @ContributesAndroidInjector
    abstract NewsDetailActivity contributesNewsDetailActivity();

    @ContributesAndroidInjector
    abstract FavouriteFragment contributesFavouriteFragment();

    @ContributesAndroidInjector
    abstract HeadlineFragment contributesHeadlineFragment();

    @ContributesAndroidInjector
    abstract SearchFragment contributesSearchFragment();

    @ContributesAndroidInjector
    abstract CategoryFragment contributesCategoryFragment();

    @ContributesAndroidInjector
    abstract SettingsActivity contributesSettingsActivity();
}

package com.newsapp.data;

import android.arch.persistence.room.TypeConverter;
import android.arch.persistence.room.TypeConverters;

public class SourceConverter {

}

package com.newsapp.di;

public interface Injectable {
}
